# Pipeline de atualização e recuperação — CODE02 v0.6.9 candidate

## Modelo de ativação

O endpoint `POST /api/v1/system/update/apply` só aceita uma operação `VERIFIED`, com versão de destino coincidente, sessão Owner e helper privilegiado instalado. A API não reinicia o próprio serviço: enfileira a operação numa unidade systemd independente e responde `202 APPLY_QUEUED`. O progresso pode ser consultado em `GET /api/v1/system/update/status`.

O helper `/usr/sbin/solarminer-update-apply` só é invocável através da regra sudoers limitada ao próprio executável. A CLI aceita exclusivamente `--preflight`, `--enqueue UUID`, `--operation UUID` e `--recover`; não aceita comandos ou caminhos arbitrários fornecidos pelo cliente. Antes da ativação, o helper volta a validar a assinatura Ed25519 do manifesto usando a chave pública root-owned, o hash/tamanho do pacote, a versão Debian e o caminho de staging.

## Máquina de estados persistente

`VERIFIED → APPLY_QUEUED → PRECHECK → BACKUP_CREATED → STAGED → SWITCHED → SERVICE_RESTARTING → HEALTH_CHECKING → COMMITTED`.

Qualquer falha após o backup entra em `ROLLING_BACK`; se o rollback e a verificação da versão anterior passarem, termina em `ROLLED_BACK`. Se não for possível provar a recuperação, termina em `RECOVERY_BLOCKED` e exige intervenção. O estado atual fica em `/opt/solarminer/update-state.json`; cada transição é acrescentada e sincronizada em `update-state.jsonl`, além de refletida em `update_operations` na SQLite. Um lock `flock` serializa ativação e recuperação.

## Backup, ativação e health check

- Backup online via SQLite backup API antes de extrair ou ativar a nova release; metadados incluem UTC, hash, tamanho e versões de schema.
- O pacote é extraído para uma nova diretoria dentro de `/opt/solarminer/releases/`; a versão ativa nunca é sobrescrita.
- O apontador `current` muda por symlink temporário + `os.replace`, seguido de `fsync` da diretoria.
- O serviço é reiniciado pela unidade independente `solarminer-update-apply@UUID.service`.
- O health check consulta `https://127.0.0.1:8443/api/v1/health` por até 60 segundos, exige HTTP 200, integridade SQLite `ok` e `package_version` igual à versão pretendida.
- Em falha, o helper para o serviço, restaura o symlink anterior, repõe o backup SQLite depois de confirmar o serviço parado, reinicia a release anterior e exige health check da versão anterior durante até 60 segundos.

## Recuperação independente

`solarminer-recovery.service` e `.timer` usam o helper fora do processo da API. O serviço é executado na inicialização e periodicamente; trata o journal antigo de conectores e a máquina de estados de atualização. Uma operação não terminal após interrupção é revertida para a release anterior. A recuperação é offline e não requer Internet/Tailscale.

## Pré-requisitos para habilitar

- `current` é um symlink para uma diretoria existente sob `/opt/solarminer/releases/`.
- `solarminer-recovery.timer` está ativo.
- A base SQLite existe e não é symlink.
- `/etc/solarminer/release-pubkey.pem` existe, pertence a root e não é gravável por grupo/outros; a chave deve ser provisionada pelo operador a partir da origem de confiança.
- `sudo` permite ao utilizador `solarminer` invocar apenas `/usr/sbin/solarminer-update-apply`; o helper valida os argumentos e revalida manifesto e pacote.
- O pacote tem arquitetura suportada e dependências compatíveis com o host.

Se qualquer pré-requisito falhar, a aplicação permanece bloqueada com HTTP 503. A validação de pacote não implica que ativação esteja disponível.

## Limites de validação

A implementação e os testes em diretórios temporários não substituem uma instalação Debian em host de ensaio. Antes de aprovar a candidata para Gateway físico, executar instalação limpa e upgrade a partir da versão efetivamente instalada, verificar permissões/units sudoers, teste de health-check falhado, SIGKILL em cada fronteira de estado, reboot durante `SWITCHED`, recuperação offline, dependências Debian e rollback SQLite real. Não declarar validação física até essa evidência existir.
